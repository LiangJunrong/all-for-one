PLM 的 VS Code 插件
===

## 一 功能实现

* [x] 输入 `@api` 自动插入代码提示块
* [x] 在方法中使用快捷键 `Command/Ctrl + Shift + I` 进行方法注释

### 1.1 @api 插入注释

在 js 文件中，输入 @api 的时候，能提示自定义的命令：

```js
/**
* @name 接口名字
* @tutorial 接口地址
* @param { Object } 接口参数
* @return 接口返回
*/
```

### 1.2 快捷键插入注释

当光标聚集于方法体的时候，使用快捷键 `Command/Ctrl + Shift + I`，会给该方法添加注释：

```js
// ---非接口---
function data1(abc, def) { }
const data2 = function(abc, def) { }
const data3 = (abc, def) => { }
const data4 = abc => { }
// ---接口---
export function getList1(abc, def) { }
export const getList2 = function(abc, def) { }
export const getList3 = (abc, def) => { }
export const getList4 = abc => { }
```

> 非接口

```js
/**
 * @name data
 * @description 功能描述
 * @param {any} abc
 * @param {any} def
 * @return 接口返回
 */
const data = (abc, def) => {
  console.log(abc, def);
}
```

> 接口

```js
/**
* @name getList
* @description API接口描述
* @address API接口地址
* @param {any} abc
* @param {any} def
*/
export const getList = (abc, def) => {
  console.log(abc, def);
}
```

## 二 参考文献

* 本插件开发文档：[plm-snippet 开发](https://github.com/LiangJunrong/document-library/tree/master/other-library/tool/Visio%20Studio%20Code)
* [【博客园】小茗同学《VSCode插件开发全攻略（一）概览》](https://www.cnblogs.com/liuxianan/p/vscode-plugin-overview.html)
* [【Visio Studio Code】插件市场](https://marketplace.visualstudio.com/vscode)
* [【Visio Studio Code】插件开发 API](https://code.visualstudio.com/api)

---

> <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="知识共享许可协议" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">jsliang 的文档库</span> 由 <a xmlns:cc="http://creativecommons.org/ns#" href="https://github.com/LiangJunrong/document-library" property="cc:attributionName" rel="cc:attributionURL">梁峻荣</a> 采用 <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">知识共享 署名-非商业性使用-相同方式共享 4.0 国际 许可协议</a>进行许可。<br />基于<a xmlns:dct="http://purl.org/dc/terms/" href="https://github.com/LiangJunrong/document-library" rel="dct:source">https://github.com/LiangJunrong/document-library</a>上的作品创作。<br />本许可协议授权之外的使用权限可以从 <a xmlns:cc="http://creativecommons.org/ns#" href="https://creativecommons.org/licenses/by-nc-sa/2.5/cn/" rel="cc:morePermissions">https://creativecommons.org/licenses/by-nc-sa/2.5/cn/</a> 处获得。